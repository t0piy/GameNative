Arquivos selecionados do repositório t0piy/GameNative-LuaTools (branch master)

Downloader / JNI:
- app/src/main/java/app/gamenative/service/download/GameDownloadService.kt
- app/src/main/java/app/gamenative/service/download/NativeSteamDownload.kt
- app/src/main/java/app/gamenative/service/download/GameDownloadNative.kt
- app/src/main/cpp/gn-download/rust/src/store_dl/steam/jni.rs
- app/src/main/cpp/gn-download/rust/src/store_dl/steam/depot_downloader.rs

VDF / KeyValue:
- app/src/main/java/app/gamenative/statsgen/VdfParser.kt
- app/src/main/java/app/gamenative/utils/KeyValueUtils.kt
- app/src/main/java/app/gamenative/utils/SteamUtils.kt
